
package hotelmanagementsystem.thread;
import hotelmanagementsystem.file.FileManager;
import hotelmanagementsystem.model.Customer;
import java.util.ArrayList;


// CustomerSaveThread will run independently from the main program
// It's responsibility is to save the customer data to a file without 
// interrupting the rest of the application
// By extending thread, the save operation can run in the background while the main
// program keeps responding to the user
public class CustomerSaveThread extends Thread {
    private FileManager fileManager;
    private ArrayList<Customer> customers;
    
    public CustomerSaveThread(FileManager fileManager, ArrayList<Customer> customers) {
        this.fileManager = fileManager;
        this.customers = customers;
    }
 
    public void run() {
        fileManager.saveCustomers(customers);
    }
}
    
    
    

