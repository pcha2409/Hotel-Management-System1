package hotelmanagementsystem.thread;
import hotelmanagementsystem.file.FileManager;
import java.util.ArrayList;
import hotelmanagementsystem.model.Booking;

// Saves booking data in a seperate background thread
// Running the save operation independently allows the Hotel Management System
// to continue responding to the user while booking information is written to the file
public class BookingSaveThread extends Thread {
    private FileManager fileManager;
    private ArrayList<Booking> bookings;
    
    // Creates a new thread responsible for saving the current list of bookings
    // fileManager handles file input/output
    // bookings is the booking list to save
    public BookingSaveThread(FileManager fileManager, ArrayList<Booking> bookings) {
        this.fileManager = fileManager;
        this.bookings = bookings;
    }
    
    // Executes when the thread starts
    // Saves all the bookings to the bookings file without interrupting the main application
    public void run() {
        fileManager.saveBookings(bookings);
    }
}
