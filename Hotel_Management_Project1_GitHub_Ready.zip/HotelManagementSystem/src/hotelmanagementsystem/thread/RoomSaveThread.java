package hotelmanagementsystem.thread;
import hotelmanagementsystem.model.Room;
import hotelmanagementsystem.file.FileManager;
import java.util.ArrayList;

// Saves room data in a seperate background thread
// This allows the application to continue responding to the user while room information is written to file
public class RoomSaveThread extends Thread {
    private FileManager fileManager;
    private ArrayList<Room> rooms;
    // Creates a thread responsible for saving current list of rooms
    // fileManager will save file input/output
    // rooms lists the rooms to save
    public RoomSaveThread(FileManager fileManager, ArrayList<Room> rooms) {
        this.fileManager = fileManager;
        this.rooms = rooms;
    }
    // Works when the thread starts
    // This will save all rooms to the rooms file without interrupting the main application
    public void run() {
        fileManager.saveRooms(rooms);
    }
}