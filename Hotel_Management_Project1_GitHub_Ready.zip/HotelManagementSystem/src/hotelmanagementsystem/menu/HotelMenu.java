// Priyanka Chaudhary
// Student ID: 24263053
// Hotel Management Project
package hotelmanagementsystem.menu;
import java.util.Scanner;
import hotelmanagementsystem.service.HotelService;
import hotelmanagementsystem.model.Room;
import hotelmanagementsystem.model.StandardRoom;
import hotelmanagementsystem.model.DeluxeRoom;
import hotelmanagementsystem.model.SuiteRoom;
import hotelmanagementsystem.model.Customer;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import hotelmanagementsystem.model.Booking;
import hotelmanagementsystem.factory.RoomFactory;


public class HotelMenu {
    
    private Scanner scanner = new Scanner(System.in);
    private HotelService hotelService;
    
    public HotelMenu(HotelService hotelService) {
        this.hotelService = hotelService;
    }
    
    // Generated with assistance from ChatGPT
    // Displays the application's main menu options to the user
    public void displayMenu() {
 
    System.out.println("===============================================");
System.out.println("      WELCOME TO THE HOTEL MANAGEMENT SYSTEM");
System.out.println("===============================================");
System.out.println("Thank you for using the Hotel Management System!");
System.out.println("This application helps you manage customers,");
System.out.println("rooms, bookings, and cancellations efficiently.");
System.out.println("Press 'Q' to quit program at any step or 'B' to go back to main menu");
System.out.println("Please select an option from the menu below.");
System.out.println();
    System.out.println("1. Add Customer");
    System.out.println("2. Add Room");
    System.out.println("3. Book Room");
    System.out.println("4. Cancel Booking");
    System.out.println("5. View Customers");
    System.out.println("6. View Rooms");
    System.out.println("7. View Bookings");
    System.out.println("8. Exit");
    System.out.println("=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.");
    
         
}
    // Prints welcome message and menu options
    // The menu continues running until the user chooses to exit the program
    public void startMenu() {
        while(true) {
            displayMenu();
            String choice = getChoice();
            processChoice(choice);
    }
    }
    
    // Reads and validates the user's main menu choice
    // Only valid menu options are accepted
    public String getChoice() {
        while(true) {
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine().trim();
            
            if (choice.equalsIgnoreCase("Q")) {
            System.out.println("Thank you for using the Hotel Management System!");
            System.exit(0);
           }
            if (choice.equals("1") ||choice.equals("2") || choice.equals("3") || choice.equals("4") ||
            choice.equals("5") || choice.equals("6") || choice.equals("7") ||choice.equals("8")) {

            return choice;
            }
          System.out.println("Invalid choice. Please enter a number between 1 and 8, or Q to quit.");
        }
        
    }
    
    // Executes the appropriate menu operation based on the user's selection
    public void processChoice(String choice) {

    switch (choice) {

        case "1":
            addCustomer();
            break;

        case "2":
            System.out.println("Add Room selected.");
            addRoom();
            break;

        case "3":
            System.out.println("Book Room selected.");
            bookRoom();
            break;

        case "4":
            System.out.println("Cancel Booking selected.");
            cancelBooking();
            break;

        case "5":
            System.out.println("View Customers selected.");
            viewCustomers();
            break;

        case "6":
            viewRooms();
            break;

        case "7":
            System.out.println("View Bookings selected.");
            viewBookings();
            break;

        case "8":

    System.out.println();
    System.out.println("Generating reports...");

    hotelService.generateCustomerReport();
    hotelService.generateRoomAvailReport();

    System.out.println();
    hotelService.viewCustomerReport();

    System.out.println();
    hotelService.viewRoomAvailReport();

    System.out.println();
    System.out.println("========================================");
    System.out.println("Thank you for using the Hotel Management System!");
    System.out.println("Goodbye!");
    System.out.println("========================================");

    System.exit(0);
    break;
    }
}
    
    // This method is for user to add a new customer into the system
    // Customer information is validated before being saved into the hotel system
  public void addCustomer() {

    System.out.println("\n--------- Add Customer ---------");

    String firstName = getValidName("First Name");
    if (firstName == null) return;

    String lastName = getValidName("Last Name");
    if (lastName == null) return;
    while(lastName.equalsIgnoreCase(firstName)) {
                            System.out.println("First and last name cannot be the same!");
                            lastName = getValidName("Last Name");
                        }

    String phoneNumber = getValidPhoneNumber();
    if (phoneNumber == null) return;

    String email = getValidEmail();
    if (email == null) return;

    while (true) {

        System.out.println();
        System.out.println("-------------------------------------------");
        System.out.println("           CUSTOMER DETAILS");
        System.out.println("-------------------------------------------");
        System.out.println("Customer      : " + firstName + " " + lastName);
        System.out.println("Phone Number  : " + phoneNumber);
        System.out.println("Email         : " + email);
        System.out.println("Allocated Customer ID: " + hotelService.getNextCustomerId());
        System.out.println("-------------------------------------------");
        System.out.println("1. Save Customer");
        System.out.println("2. Edit Information");
        System.out.println("3. Cancel");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine().trim();

        switch (choice) {

            case "1":

                hotelService.addCustomer(firstName, lastName, phoneNumber, email);

                System.out.println();
                System.out.println("Customer added successfully!");
                System.out.println("Press Enter to return to the Main Menu...");
                scanner.nextLine();
                return;

            case "2":

                System.out.println();
                System.out.println("Which information would you like to edit?");
                System.out.println("1. First Name");
                System.out.println("2. Last Name");
                System.out.println("3. Phone Number");
                System.out.println("4. Email");
                System.out.print("Enter your choice: ");

                String editChoice = scanner.nextLine().trim();

                switch (editChoice) {

                    case "1":
                        firstName = getValidName("First Name");
                        break;

                    case "2":
                        lastName = getValidName("Last Name");
                        if(lastName.equalsIgnoreCase(firstName)) {
                            System.out.println("First and last name cannot be the same!");
                            lastName = getValidName("Last Name");
                        }
                        break;

                    case "3":
                        phoneNumber = getValidPhoneNumber();
                        break;

                    case "4":
                        email = getValidEmail();
                        break;

                    default:
                        System.out.println("Invalid choice.");
                }

                break;

            case "3":
                return;

            default:
                System.out.println("Invalid choice.");
        }
    }
}
  // This method is reusable for both first/last name
  // Checks validity of first/last name
  // The method validates length, allowed characters, and supports quitting/returning to main menu
  private String getValidName(String label) {
      while (true) {
          System.out.print(label + ": ");
          String input = scanner.nextLine().trim();
          
          
if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

    if (handleQuitOrBack(input)) {
        return null;
    }

    // User answered N, so ask for this field again
    continue;
}
          
          if (input.isEmpty()) {
              System.out.println("Error: " + label + " cannot be empty.");
              continue;
          }
          // Name should not be more than 15 characters in length 
          if (input.length()>15) {
              System.out.println("Error: " + label + " cannot be longer than 15 characters.");
              continue;
          }
          if(!input.matches("[A-Za-z' -]+")) {
              System.out.println("Error: " + label + " contains invalid characters.");
              System.out.println("Please use letters only.");
              continue;
          }
          
          input = input.substring(0,1).toUpperCase() + input.substring(1).toLowerCase();
          return input;
          
      }
     
  }
  // Prompts user for valid email address
  // Tests for @ and . symbols in the email address, user email address can also not end with a '.'
  private String getValidEmail() {

    while (true) {

        System.out.print("Email: ");
        String input = scanner.nextLine().trim().toLowerCase();
        
        
if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

    if (handleQuitOrBack(input)) {
        return null;
    }

    // User answered N, so ask for this field again
    continue;
}     



        if (input.isEmpty()) {
            System.out.println("Error: Email cannot be empty.");
            continue;
        }

        if (!input.contains("@")) {
            System.out.println("Error: Email must contain '@'.");
            continue;
        }

        if (!input.contains(".")) {
            System.out.println("Error: Email must contain a '.'.");
            continue;
        }

        if (input.startsWith("@") || input.endsWith("@")) {
            System.out.println("Error: Invalid email address.");
            continue;
        }

        if (input.endsWith(".")) {
            System.out.println("Error: Invalid email address.");
            continue;
        }

        return input;
    }
}
  
  // Generated by ChatGPT
  // Tests for invalid input by user input not being empty, and has to be between 8 and 15 digits
  // Also tests for digits only
  private String getValidPhoneNumber() {

    while (true) {

        System.out.print("Phone Number: ");
        String input = scanner.nextLine().trim();

        
if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

    if (handleQuitOrBack(input)) {
        return null;
    }

    // User answered N, so ask for this field again
    continue;
}
        
        if (input.isEmpty()) {
            System.out.println("Error: Phone Number cannot be empty.");
            continue;
        }

        if (input.length() < 8 || input.length() > 15) {
            System.out.println("Error: Phone Number must be between 8 and 15 digits.");
            continue;
        }

        boolean valid = true;

        for (int i = 0; i < input.length(); i++) {

            if (!Character.isDigit(input.charAt(i))) {
                valid = false;
                break;
            }

        }

        if (!valid) {
            System.out.println("Error: Phone Number must contain digits only.");
            continue;
        }

        return input;
    }
}
  // This handles user typing Q to quit or B to go back, any time they input during program
  // If user chooses to quit it will print the reports of the customers and room availability before quitting
  private boolean handleQuitOrBack(String input) {

    if (!input.equalsIgnoreCase("Q") && !input.equalsIgnoreCase("B")) {
        return false;
    }

    while (true) {

        String message;

        if (input.equalsIgnoreCase("Q")) {
            message = "Are you sure you want to quit? Your progress will not be saved. (Y/N): ";
        } else {
            message = "Are you sure you want to return to the Main Menu? Unsaved changes will be lost. (Y/N): ";
        }

        System.out.print(message);
        String answer = scanner.nextLine().trim();

        if (answer.isEmpty()) {
            System.out.println("Error: Input cannot be empty.");
            continue;
        }

        if (answer.equalsIgnoreCase("Y")) {

            if (input.equalsIgnoreCase("Q")) {

    System.out.println();
    System.out.println("Generating reports...");

    hotelService.generateCustomerReport();
    hotelService.generateRoomAvailReport();

    System.out.println();
    hotelService.viewCustomerReport();

    System.out.println();
    hotelService.viewRoomAvailReport();

    System.out.println();
    System.out.println("========================================");
    System.out.println("Thank you for using the Hotel Management System!");
    System.out.println("Goodbye!");
    System.out.println("========================================");

    System.exit(0);
}

            return true;
        }

        if (answer.equalsIgnoreCase("N")) {
            return false;
        }

        System.out.println("Error: Please enter Y or N.");
    }
}
  
  // Displays the room management menu and allows the user to add a new room
  private void addRoom() {

    while (true) {

        System.out.println("\n========= Add Room =========");
        System.out.println("1. Add Room to Hotel");
        System.out.println("2. Back");
   
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine().trim();

        if (choice.equalsIgnoreCase("Q") || choice.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(choice)) {
                return;
            }

            continue;
        }

        switch (choice) {
            case "1":
                addSingleRoom();
                return;
            case "2":
                return;

            default:
                System.out.println();
                System.out.println("!!Invalid choice!!");
                System.out.println();
        }
    }
}
  // Collects information to create a single room before saving it
  private void addSingleRoom() {

    System.out.println("\n--------- Add Single Room ---------");

    int roomNumber = getValidRoomNumber();
    if (roomNumber == -1) {
        return;
    }

    Room room = null;

    while (true) {

        System.out.println();
        System.out.println("Room Type");
        System.out.println("1. Standard");
        System.out.println("2. Deluxe");
        System.out.println("3. Suite");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine().trim();

        if (choice.equalsIgnoreCase("Q") || choice.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(choice)) {
                return;
            }

            continue;
        }
        
        String roomType;
        switch (choice) {
            case "1":
                roomType = "StandardRoom";
                break;

            case "2":
                roomType = "DeluxeRoom";
                break;

            case "3":
                roomType = "SuiteRoom";
                break;

            default:
                System.out.println("Invalid choice.");
                continue;
        }
        room = RoomFactory.createRoom(roomType, roomNumber, true);

        break;
    }

    while (true) {

        System.out.println();
        System.out.println("-------------------------------------------");
        System.out.println("              ROOM DETAILS");
        System.out.println("-------------------------------------------");
        System.out.println("Room Number     : " + room.getRoomNumber());
        System.out.println("Room Type       : " + room.getClass().getSimpleName().replace("Room", ""));
        System.out.printf("Price Per Night : $%.2f%n", room.getPricePerNight());
        System.out.println("Capacity        : " + room.getCapacity());
        System.out.println("Availability    : Available");
        System.out.println("-------------------------------------------");
        System.out.println("1. Save Room");
        System.out.println("2. Edit Information");
        System.out.println("3. Cancel");
        System.out.print("Enter your choice: ");

        String choice = scanner.nextLine().trim();

        if (choice.equalsIgnoreCase("Q") || choice.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(choice)) {
                return;
            }

            continue;
        }

        switch (choice) {

            case "1":
                hotelService.addRoom(room);
                System.out.println();
                System.out.println("Room added successfully!");
                System.out.println("Press Enter to return to the Main Menu...");
                scanner.nextLine();
                return;

            case "2":
                addSingleRoom();
                return;

            case "3":
                return;

            default:
                System.out.println("Invalid choice.");
        }
    }
}
  
  // Method to get user to input a single valid room number
  // User is able to quit or go back at any step in the program
  private int getValidRoomNumber() {

    while (true) {

        System.out.print("Room Number: ");
        String input = scanner.nextLine().trim();

        if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(input)) {
                return -1;
            }

            continue;
        }

        if (input.isEmpty()) {
            System.out.println("Error: Room Number cannot be empty.");
            continue;
        }

        boolean valid = true;

        for (int i=0; i<input.length(); i++) {

            if (!Character.isDigit(input.charAt(i))) {
                valid = false;
                break;
            }
        }

        if (!valid) {
            System.out.println("Error: Room Number must contain digits only.");
            continue;
        }

        int roomNumber;
        try {
            roomNumber = Integer.parseInt(input);
            
        } 
        catch(NumberFormatException error) {
            System.out.println("ERROR! The Room number is too large!");
            continue;
        }

        if (roomNumber <= 0) {
            System.out.println("Error: Room Number must be greater than 0.");
            continue;
        }

        if (hotelService.roomExists(roomNumber)) {
            System.out.println("Error: Room Number already exists.");
            continue;
        }

        return roomNumber;
    }
}
  
  // Displays all rooms currently stored in the hotel system
  // Also allows rooms without active bookings to be deleted
  private void viewRooms() {

    System.out.println("\n--------- View Rooms ---------");

    if (hotelService.getRooms().isEmpty()) {
        System.out.println("There are no rooms in the system.");
        return;
    }

    for (Room room : hotelService.getRooms()) {

        System.out.println("----------------------------");
        System.out.println("Room Number: " + room.getRoomNumber());

        if (room instanceof StandardRoom) {
            System.out.println("Room Type: Standard");
        }
        else if (room instanceof DeluxeRoom) {
            System.out.println("Room Type: Deluxe");
        }
        else if (room instanceof SuiteRoom) {
            System.out.println("Room Type: Suite");
        }

        System.out.println("Price Per Night: $" + room.getPricePerNight());
        System.out.println("Capacity: " + room.getCapacity());

        if (room.isAvailable()) {
            System.out.println("Availability: Available");
        }
        else {
            System.out.println("Availability: Unavailable");
        }
        
     
        
    }
    boolean choice = askYesNo("Would you like to delete a room?");

if (choice) {

    while (true) {

        System.out.print("Enter Room Number (B to go back, Q to quit): ");
        String input = scanner.nextLine().trim();

        if (input.equalsIgnoreCase("B")) {
            return;
        }

        if (input.equalsIgnoreCase("Q")) {

            if (handleQuitOrBack(input)) {
                return;
            }

            continue;
        }

        if (!input.matches("\\d+")) {
            System.out.println("Error: Please enter numbers only.");
            continue;
        }

        int roomNumber;

        try {
            roomNumber = Integer.parseInt(input);
        }
        catch (NumberFormatException error) {
            System.out.println("ERROR! The Room number is too large!");
            continue;
        }

        if (hotelService.deleteRoom(roomNumber)==true) {
            System.out.println();
            System.out.println("Room deleted successfully!");
            break;

        } else {
            System.out.println("Room cannot be deleted because it has an active booking or does not exist.");
        }

    }

}

    System.out.println("----------------------------");
    System.out.println("Press Enter to return to the Main Menu...");
    scanner.nextLine();
}
  
  // Displays every customer currently stored in the hotel system
  // Customers without active bookings only may be deleted
  private void viewCustomers() {

    System.out.println("\n--------- View Customers ---------");

    if (hotelService.getCustomers().isEmpty()) {
        System.out.println("There are no customers in the system.");
        System.out.println("Press Enter to return to the Main Menu...");
        scanner.nextLine();
        return;
    }

    for (Customer customer : hotelService.getCustomers()) {

        System.out.println("-------------------------------------");
        System.out.println("Customer ID: " + customer.getCustomerId());
        System.out.println("Name: " + customer.getFirstName() + " " + customer.getLastName());
        System.out.println("Phone Number: " + customer.getPhoneNumber());
        System.out.println("Email: " + customer.getEmail());

        if (customer.isMember()) {
            System.out.println("Membership: Active");
        } else {
            System.out.println("Membership: Not a Member");
        }
    }
    
     // User is asked if this customer needs to be deleted from the system
    boolean choice = askYesNo("Would you like to delete a customer?");

if (choice) {

    while (true) {

        System.out.print("Enter Customer ID (or B to go back, Q to quit): ");
        String input = scanner.nextLine().toUpperCase();

        if (input.equals("B")) {
            scanner.nextLine();
            return;
        }

        if (input.equals("Q")) {
            System.exit(0);   // or whatever method you already use
        }

        try {

            int customerId;

        try {
            customerId = Integer.parseInt(input);
        } catch (NumberFormatException error) {
            System.out.println("Error! Customer ID is too large.");
            continue;
        }
            
            if (customerId<=0) {
                System.out.println("Error! Customer ID must be greater than 0");
                continue;
            }

            if (hotelService.deleteCustomer(customerId)) {
                System.out.println();
                System.out.println();
                System.out.println("-----------Customer deleted successfully---------");
                System.out.println();
                System.out.println();
                break;
            } else {
                System.out.println("Customer cannot be deleted because they have an active booking or do not exist.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid Customer ID, B or Q.");
        }
    }
}

    System.out.println("-------------------------------------");
    System.out.println("Press Enter to return to the Main Menu...");
    scanner.nextLine();
    
    
}
  
  // Displays a yes/no question and validates the user response
  // return true for yes, false for no
  private boolean askYesNo(String question) {

    while (true) {

        System.out.print(question + " (Y/N): ");

        String input = scanner.nextLine().trim();

        if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(input)) {
                return false;
            }

            continue;
        }

        if (input.equalsIgnoreCase("Y")) {
            return true;
        }

        if (input.equalsIgnoreCase("N")) {
            return false;
        }

        System.out.println("Error: Please enter Y or N.");

    }

}
  // Prompts the user for a valid customer ID
  // Return a valid customer ID or -1 if cancelled
  private int getValidCustomerId() {

    while (true) {

        System.out.print("Customer ID: ");
        String input = scanner.nextLine().trim();

        if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(input)) {
                return -1;
            }

            continue;
        }

        if (input.isEmpty()) {
            System.out.println("Error: Customer ID cannot be empty.");
            continue;
        }

        boolean valid = true;

        for (int i = 0; i < input.length(); i++) {

            if (!Character.isDigit(input.charAt(i))) {
                valid = false;
                break;
            }

        }

        if (!valid) {
            System.out.println("Error: Customer ID must contain digits only.");
            continue;
        }

        int customerId;

        try {
            customerId = Integer.parseInt(input);
        }
        catch (NumberFormatException error) {
            System.out.println("Error! Customer ID is too large.");
            continue;
        }

        if (customerId <= 0) {
            System.out.println("Error: Customer ID must be greater than 0.");
            continue;
        }

        if (hotelService.findCustomerById(customerId) == null) {
            System.out.println("Error: Customer does not exist.");
            continue;
        }

        return customerId;
    }
}
  
  // Prompts the user for an available room that exists in the hotel
  // Return the selected room number or -1 if cancelled
  private int getValidBookingRoomNumber() {

    while (true) {

        System.out.print("Room Number: ");
        String input = scanner.nextLine().trim();

        if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(input)) {
                return -1;
            }

            continue;
        }

        if (input.isEmpty()) {
            System.out.println("Error: Room Number cannot be empty.");
            continue;
        }

        boolean valid = true;

        for (int i = 0; i < input.length(); i++) {

            if (!Character.isDigit(input.charAt(i))) {
                valid = false;
                break;
            }

        }

        if (!valid) {
            System.out.println("Error: Room Number must contain digits only.");
            continue;
        }

        int roomNumber;
        
        try {
            roomNumber = Integer.parseInt(input);
        } 
        catch (NumberFormatException error) {
            System.out.println("Error! Room number is too large");
            continue;
        }

        if (roomNumber <= 0) {
            System.out.println("Error: Room Number must be greater than 0.");
            continue;
        }

        Room room = hotelService.findRoomByNumber(roomNumber);

        if (room == null) {
            System.out.println("Error: Room does not exist.");
            continue;
        }

        if (!room.isAvailable()) {
            System.out.println("Error: Room is already booked.");
            continue;
        }

        return roomNumber;
    }
}
  // Prompts the user for the number of guests
  // The value MUST NOT exceed the room capacity
  private int getValidGuestNumber(Room room) {

    while (true) {

        System.out.print("Number of Guests: ");
        String input = scanner.nextLine().trim();

        if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

            if (handleQuitOrBack(input)) {
                return -1;
            }

            continue;
        }

        if (input.isEmpty()) {
            System.out.println("Error: Number of Guests cannot be empty.");
            continue;
        }

        boolean valid = true;

        for (int i = 0; i < input.length(); i++) {

            if (!Character.isDigit(input.charAt(i))) {
                valid = false;
                break;
            }

        }

        if (!valid) {
            System.out.println("Error: Please enter digits only.");
            continue;
        }

        int guests;

        try {
            guests = Integer.parseInt(input);
        } catch (NumberFormatException error) {
            System.out.println("Error! Number of guests is too large.");
            continue;
        }

        if (guests <= 0) {
            System.out.println("Error: Number of guests must be greater than 0.");
            continue;
        }

        if (guests > room.getCapacity()) {
            System.out.println("Error: Maximum capacity for this room is " + room.getCapacity() + ".");
            continue;
        }

        return guests;
    }

  }
 
  // Guides the user through the booking process
  // Customer details, room details, dates, optional services and pricing are collected
 // before creating the booking
  // Check in date MUST be before the check out date
  private void bookRoom() {
      System.out.println("=======================BOOK ROOM=====================");
      
      int customerId = getValidCustomerId();
      if(customerId == -1) {
          return;
      }
      Customer customer = hotelService.findCustomerById(customerId);
      
      int roomNumber = getValidBookingRoomNumber();
      if (roomNumber == -1) {
          return;
      }
      Room room = hotelService.findRoomByNumber(roomNumber);
      
      int numberOfGuests = getValidGuestNumber(room);
      if(numberOfGuests == -1) {
          return;
      }
      LocalDate checkInDate;
      
      while(true) {
          System.out.println("Check in Date: (dd/mm/yyyy): ");
          String input = scanner.nextLine().trim();
          if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {
              if(handleQuitOrBack(input)) {
                  return;
              }
              continue;
          }
          try {

    DateTimeFormatter formatter =
            // This tells Java the order of the day, month, year
            DateTimeFormatter.ofPattern("dd/MM/yyyy");

    checkInDate = LocalDate.parse(input, formatter);

    if (checkInDate.isBefore(LocalDate.now())) {
        System.out.println("Error: Check in date cannot be before today.");
        continue;
    }

    break;

} catch (Exception e) {

    System.out.println("Error: Please enter a valid date.");

}
      
  }
      LocalTime checkInTime;

while (true) {

    System.out.print("Check-in Time (HH:mm): ");

    String input = scanner.nextLine().trim();

    if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

        if (handleQuitOrBack(input)) {
            return;
        }

        continue;
    }

    try {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

        checkInTime = LocalTime.parse(input, formatter);

        break;

    } catch (Exception e) {

        System.out.println("Error: Please enter a valid time.");

    }

}
  LocalDate checkOutDate;

while (true) {

    System.out.print("Check-out Date (dd/MM/yyyy): ");

    String input = scanner.nextLine().trim();

    if (input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("B")) {

        if (handleQuitOrBack(input)) {
            return;
        }

        continue;
    }

    try {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        checkOutDate = LocalDate.parse(input, formatter);

        if (!checkOutDate.isAfter(checkInDate)) {
            System.out.println("Error: Check-out date must be after the check-in date.");
            continue;
        }

        break;

    } catch (Exception e) {

        System.out.println("Error: Please enter a valid date.");

    }

}
    // This is to ask for optional add ons 
    boolean extraBed = askYesNo("Would you like to add an Extra Bed ($40)?");
    boolean lateCheckOut = askYesNo("Would you like Late Check-out ($30)?");
    boolean airportShuttle = askYesNo("Would you like an Airport Shuttle ($60)?");
    
    // Customer can also own a hotel membership for if they visit multiple times
    // This has added benefits for them
    boolean purchaseMembership = false;

if (!customer.isMember()) {

    System.out.println();
    System.out.println("Hotel Membership");
    System.out.println("----------------");
    System.out.println("Fee: $75");
    System.out.println("Benefits:");
    System.out.println("- 10% discount on every booking");
    

    purchaseMembership = askYesNo("Purchase membership?");
}

boolean successBooking = hotelService.bookRoom(
        customerId,
        roomNumber,
        checkInDate,
        checkInTime,
        checkOutDate,
        numberOfGuests,
        extraBed,
        lateCheckOut,
        airportShuttle,
        purchaseMembership
);

if (successBooking) {

    System.out.println();
    System.out.println("Booking created successfully!");

} else {

    System.out.println();
    System.out.println("Booking could not be created.");

}
long nights = ChronoUnit.DAYS.between(checkInDate, checkOutDate);

double roomCharge = room.getPricePerNight() * nights;

double addOnCharge = 0;

if (extraBed) {
    addOnCharge += 40;
}

if (lateCheckOut) {
    addOnCharge += 30;
}

if (airportShuttle) {
    addOnCharge += 60;
}

// If the person has purchased a membership they don't have to pay for add ons
if (purchaseMembership) {

    if (airportShuttle) {
        addOnCharge -= 60;
    }
    else if (extraBed) {
        addOnCharge -= 40;
    }
    else if (lateCheckOut) {
        addOnCharge -= 30;
    }

}

double membershipFee = purchaseMembership ? 75 : 0;
// If customer is a member or chooses to purchase a membership then they get 10% discount, else no discount
double discount = (customer.isMember() || purchaseMembership) 
        ? roomCharge * 0.10
        : 0;

double total = roomCharge + addOnCharge + membershipFee - discount;
System.out.println();
System.out.println("========== Booking Summary ==========");
System.out.println("Customer: " + customer.getFirstName() + " " + customer.getLastName());
System.out.println("Room: " + room.getRoomNumber());
System.out.println("Guests: " + numberOfGuests);
System.out.println("Check-in: " + checkInDate + " " + checkInTime);
System.out.println("Check-out: " + checkOutDate + "12:00");
System.out.println("Nights: " + nights);
System.out.println();
System.out.println("Room Charge: $" + roomCharge);
System.out.println("Additional Services: $" + addOnCharge);
System.out.println("Membership Fee: $" + membershipFee);
System.out.println("Member Discount: -$" + discount);
System.out.println("-------------------------------------");
System.out.println("TOTAL: $" + total);
System.out.println("=====================================");
    
  }
    
  // Displaying every booking currently stored in the hotel system
  private void viewBookings() {

    System.out.println("\n--------- View Bookings ---------");

    if (hotelService.getBookings().isEmpty()) {

        System.out.println("There are no bookings in the system.");
        System.out.println("Press Enter to return to the Main Menu...");
        scanner.nextLine();
        return;

    }

    for (Booking booking : hotelService.getBookings()) {

        System.out.println("-----------------------------------------");
        System.out.println("Booking ID: " + booking.getBookingId());

        System.out.println("Customer: " + booking.getCustomer().getFirstName()+ " " + booking.getCustomer().getLastName());

        System.out.println("Room Number: "+ booking.getRoom().getRoomNumber());

        System.out.println("Guests: "+ booking.getNumberOfGuests());

        System.out.println("Check-in: "+ booking.getCheckInDate()+ " "+ booking.getCheckInTime());

        System.out.println("Check-out: "+ booking.getCheckOutDate()+ " "+ booking.getCheckOutTime());

        System.out.println("Extra Bed: "+ (booking.isExtraBed() ? "Yes" : "No"));

        System.out.println("Late Check-out: "+ (booking.isLateCheckOut() ? "Yes" : "No"));

        System.out.println("Airport Shuttle: "+ (booking.isAirportShuttle() ? "Yes" : "No"));

        System.out.printf("Total Price: $%.2f%n", booking.getTotalPrice());

    }

    System.out.println("-----------------------------------------");
    System.out.println("Press Enter to return to the Main Menu...");
    scanner.nextLine();
}
    
// Allows the user to cancel an existing booking
  // The booking is confirmed before the removal
 private void cancelBooking() {
     System.out.println("\n================CANCEL BOOKING=============");
     if (hotelService.getBookings().isEmpty()) {
         System.out.println("There are no bookings to cancel here");
         System.out.println("Press enter to return to main menu");
         scanner.nextLine();
         return;
     }
     int bookingId = getValidBookingId();
     if(bookingId == -1) {
         return;
     }
     Booking booking = hotelService.findBookingById(bookingId);
     if (booking == null) {
         System.out.println("Booking not found");
         return;
     }
        System.out.println();
        System.out.println("=============Booking Found===========");
        System.out.println("----------------------");
        System.out.println("Booking ID: " + booking.getBookingId());
        System.out.println("Customer: " + booking.getCustomer().getFirstName() + " " + booking.getCustomer().getLastName());
        System.out.println("Room: " + booking.getRoom().getRoomNumber());
        boolean confirming = askYesNo("Are you sure you want to cancel this booking?");
        if(!confirming) {
            return;
        }
        else {
            hotelService.cancelBooking(bookingId);
            
        }
     
 }
 
 // Prompts the user for a valid booking id
 private int getValidBookingId() {
         while (true) {
             System.out.println("Enter booking ID (B to go back, Q to quit):");
             String input = scanner.nextLine().trim();
             if(input.equalsIgnoreCase("B") || input.equalsIgnoreCase("Q")) {
                 if (handleQuitOrBack(input)) {
                     return -1;
                 }
                 continue;
             }
            if(!input.matches("\\d+")) {
             System.out.println("ERROR: Only enter numbers!");
             continue;
         } 
            int bookingId;

            try {
                bookingId = Integer.parseInt(input);
            } catch (NumberFormatException error) {
                System.out.println("Error! Booking ID is too large.");
                continue;
            }

            if (bookingId <= 0) {
                System.out.println("Error: Booking ID must be greater than 0.");
                continue;
            }

            return bookingId;
         }
     }

  }
  

  
 

