
package hotelmanagementsystem.interfaces;

/**
 *
 * @author pcha2
 */

// Represents anything capable of calculating a price
// This interface provides a common contract that different
// classes can implement if they need pricing behaviour
public interface Chargeable {
   double calculatePrice(int numberOfNights); 
}
