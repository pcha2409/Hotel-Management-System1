package hotelmanagementsystem.main;

import hotelmanagementsystem.menu.HotelMenu;
import hotelmanagementsystem.file.FileManager;
import hotelmanagementsystem.service.HotelService;

public class Main {

    public static void main(String[] args) {
        // Instead of each class creating it's own objects, I create them once and pass to classes that need them
        FileManager fileManager = new FileManager();
        HotelService hotelService = new HotelService(fileManager);
        HotelMenu menu = new HotelMenu(hotelService);
        menu.startMenu();

    }
}