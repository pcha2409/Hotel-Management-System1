package hotelmanagementsystem.model;
import hotelmanagementsystem.interfaces.Chargeable;
/**
 * Represents common information shared by all room types
 * This class is abstract because rooms are always specific types,
 * such as Standard, Deluxe or Suite.
 */
// Using an interface allows other classes (such as future hotel services)
// to also calculate prices without needing to inherit from room
public abstract class Room implements Chargeable {
    private int roomNumber;
    private double pricePerNight;
    private boolean available;
    // Used to ensure a room is suitable for the number of guests in a booking.
    private int capacity;

    public Room(int roomNumber, double pricePerNight, boolean available, int capacity) {
        this.roomNumber = roomNumber;
        this.pricePerNight = pricePerNight;
        this.available = available;
        this.capacity = capacity;
    }
    
    // Required by the chargeable interface
    // Each room calculates price differently
    @Override
    public abstract double calculatePrice(int numberOfNights);

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    
}