package hotelmanagementsystem.model;

public class DeluxeRoom extends Room {

    public DeluxeRoom(int roomNumber, boolean available) {
        super(roomNumber, 260.00, available, 4);
    }

    @Override
    public double calculatePrice(int numberOfNights) {
        return getPricePerNight() * numberOfNights;
    }
}