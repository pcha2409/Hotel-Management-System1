package hotelmanagementsystem.model;

public class SuiteRoom extends Room {

    public SuiteRoom(int roomNumber, boolean available) {
        super(roomNumber, 420.00, available, 6);
    }

    @Override
    public double calculatePrice(int numberOfNights) {
        return getPricePerNight() * numberOfNights;
    }
}