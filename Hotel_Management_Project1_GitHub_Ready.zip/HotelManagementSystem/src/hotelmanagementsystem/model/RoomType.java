package hotelmanagementsystem.model;

public enum RoomType {

    STANDARD,
    DELUXE,
    SUITE

}
