package hotelmanagementsystem.model;

public class StandardRoom extends Room {

    public StandardRoom(int roomNumber, boolean available) {
    super(roomNumber, 180.00, available, 2);
}

    @Override
    public double calculatePrice(int numberOfNights) {
        return getPricePerNight() * numberOfNights;
    }
}