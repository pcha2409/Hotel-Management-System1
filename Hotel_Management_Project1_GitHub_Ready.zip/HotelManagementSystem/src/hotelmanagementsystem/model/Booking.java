package hotelmanagementsystem.model;

import java.time.LocalDate;
import java.time.LocalTime;

// Represents a hotel booking made by a customer
public class Booking {

    private int bookingId;
    private Customer customer;
    private Room room;

    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    private LocalTime checkInTime;
    private LocalTime checkOutTime;

    private int numberOfGuests;

    // Optional additional services
    private boolean extraBed;
    private boolean lateCheckOut;
    private boolean airportShuttle;

    // Booking price breakdown
    private double roomCharge;
    private double addOnCharge;
    private double membershipFee;
    private double memberDiscount;
    private double totalPrice;

    public Booking(int bookingId,
                   Customer customer,
                   Room room,
                   LocalDate checkInDate,
                   LocalDate checkOutDate,
                   LocalTime checkInTime,
                   LocalTime checkOutTime,
                   int numberOfGuests,
                   boolean extraBed,
                   boolean lateCheckOut,
                   boolean airportShuttle,
                   double roomCharge,
                   double addOnCharge,
                   double membershipFee,
                   double memberDiscount,
                   double totalPrice) {

        this.bookingId = bookingId;
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.checkInTime = checkInTime;
        this.checkOutTime = checkOutTime;
        this.numberOfGuests = numberOfGuests;
        
        // Add ons optional 
        this.extraBed = extraBed;
        this.lateCheckOut = lateCheckOut;
        this.airportShuttle = airportShuttle;
        
        this.roomCharge = roomCharge;
        this.addOnCharge = addOnCharge;
        this.membershipFee = membershipFee;
        this.memberDiscount = memberDiscount;
        this.totalPrice = totalPrice;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public LocalTime getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(LocalTime checkInTime) {
        this.checkInTime = checkInTime;
    }

    public LocalTime getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(LocalTime checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public int getNumberOfGuests() {
        return numberOfGuests;
    }

    public void setNumberOfGuests(int numberOfGuests) {
        this.numberOfGuests = numberOfGuests;
    }

    public boolean isExtraBed() {
        return extraBed;
    }

    public void setExtraBed(boolean extraBed) {
        this.extraBed = extraBed;
    }

    public boolean isLateCheckOut() {
        return lateCheckOut;
    }

    public void setLateCheckOut(boolean lateCheckOut) {
        this.lateCheckOut = lateCheckOut;
    }

    public boolean isAirportShuttle() {
        return airportShuttle;
    }

    public void setAirportShuttle(boolean airportShuttle) {
        this.airportShuttle = airportShuttle;
    }

    public double getRoomCharge() {
        return roomCharge;
    }

    public void setRoomCharge(double roomCharge) {
        this.roomCharge = roomCharge;
    }

    public double getAddOnCharge() {
        return addOnCharge;
    }

    public void setAddOnCharge(double addOnCharge) {
        this.addOnCharge = addOnCharge;
    }

    public double getMembershipFee() {
        return membershipFee;
    }

    public void setMembershipFee(double membershipFee) {
        this.membershipFee = membershipFee;
    }

    public double getMemberDiscount() {
        return memberDiscount;
    }

    public void setMemberDiscount(double memberDiscount) {
        this.memberDiscount = memberDiscount;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}