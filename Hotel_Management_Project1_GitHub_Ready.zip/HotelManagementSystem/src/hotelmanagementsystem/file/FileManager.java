/**
 *
 * @author pcha2
 */
package hotelmanagementsystem.file;
// All imports below
import hotelmanagementsystem.model.Customer;
import hotelmanagementsystem.model.Room;
import hotelmanagementsystem.model.Booking;
import java.time.LocalDate;
import java.time.LocalTime;
import hotelmanagementsystem.service.HotelService;
import hotelmanagementsystem.model.StandardRoom;
import hotelmanagementsystem.model.DeluxeRoom;
import hotelmanagementsystem.model.SuiteRoom;
import hotelmanagementsystem.factory.RoomFactory;

import java.util.ArrayList;
// Writes the text
import java.io.FileWriter;
// Opens existing file so we can read it
import java.io.FileReader;
import java.io.BufferedWriter;
// Reads one line at a time
import java.io.BufferedReader;
// Can be seen in catch statement
import java.io.IOException;

// Handles all file input/output operations for Hotel Management System
// Responsible for saving and loading customers, rooms, bookings and reports so that data is saved after program closes
public class FileManager {
 
    // Will save all customers to text file
    // Each customer is written as comma seperated line so can be constructed again when program restarts
    // customers is the list of customers to save
    public void saveCustomers(ArrayList<Customer> customers) {
     try {
         // This will create (or overwrite) the customer file
         BufferedWriter writer = new BufferedWriter(new FileWriter("customers.txt"));
         // Save every customer stored in memory currently
         for(Customer customer: customers) {
             // Storing each customer in a fixed order
             // This order must match loadCustomers()
             writer.write( customer.getCustomerId() + "," + customer.getFirstName() + ","   + customer.getLastName() + ","
        +customer.getPhoneNumber()+","
        +customer.getEmail()+","
        +customer.isMember());
            // Move to next line ready for next customer
             writer.newLine();
         }
         // Closing file when all data is written
         writer.close();
     }   
     catch (IOException err) {
         System.out.println("Error saving customers");
     }
}

    // Loads customers from the customer file when application starts
    // Each line is converted back into Customer object and added to HotelService
    // hotelService is used to store the reconstructed customers
public void loadCustomers(HotelService hotelService) {
    try {
        // Opening the customer file for reading
        BufferedReader reader = new BufferedReader(new FileReader("customers.txt"));
        // New string named line
        String line;
        // Reading one line at a time until the end of the file
        while ((line = reader.readLine()) != null) {
            // Splitting comma seperated line into individual values
            String[] data = line.split(",");
            
            // Help aided by ChatGPT just to do these repetitive parseInt and parseBoolean sections for quicker work
            int customerId = Integer.parseInt(data[0]);
            String firstName = data[1];
            String lastName = data[2];
            String phoneNumber = data[3];
            String email = data[4];
            boolean member = Boolean.parseBoolean(data[5]);
            
             // This is recreating customer object using values read from the file
            Customer customer = new Customer(customerId, firstName, lastName, phoneNumber, email,member);
            // Adding the reconstructed customer back into the hotel system
            hotelService.addCustomer(customer);
        }
        // Closes the reader
        reader.close();
        // If the file does not exist yet then start with an empty customer list
    } catch (IOException errorShown) {
        // Start with empty data
    }
}

//Saves all rooms to text file
// Room number, room type and availability are stored so rooms can be recreated when application starts
// rooms are the rooms to be saved
public void saveRooms(ArrayList<Room> rooms) {
    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter("rooms.txt"));
        for (Room room:rooms) {
            writer.write(room.getRoomNumber() + "," +room.getClass().getSimpleName() + "," +room.isAvailable());
            writer.newLine();
        }
        writer.close();
    } catch (IOException err) {
        System.out.println("Error saving rooms");
    }
}

// Loads rooms from the room file
// Uses the factory pattern to recreate the correct room type
// hotelService stores the reconstructed rooms
public void loadRooms(HotelService hotelService) {
    try {
        BufferedReader reader = new BufferedReader(new FileReader("rooms.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            // Help aided by ChatGPT to do the parseInt and parseBoolean parts
            int roomNumber = Integer.parseInt(data[0]);
            String roomType = data[1];
            boolean available = Boolean.parseBoolean(data[2]);
            //Convert each saved room back into correct Room subclass
            Room room = RoomFactory.createRoom(roomType, roomNumber, available);
            if(room==null) {
                continue;
            }
            hotelService.addRoom(room);
        }
        reader.close();
    } catch (IOException err) {
        // Empty
 

    }

}

public void loadCustomerReport() {
    try {
        BufferedReader reader = new BufferedReader(new FileReader("customerReport.txt"));
        String line;
        while ((line =reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();
    } catch (IOException err) {
        // Empty
    }

}

// Generates a formatted customer report and will save as a text file
public void saveCustomerReport(ArrayList<Customer> customers) {

    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter("customerReport.txt"));
        writer.write("========================================");
        writer.newLine();
        writer.write("          CUSTOMER REPORT");
        writer.newLine();
        writer.write("========================================");
        writer.newLine();
        writer.newLine();
        // Write the details of each customer
        for (Customer customer : customers) {

            writer.write("Customer ID : "+ customer.getCustomerId());
            writer.newLine();

            writer.write("Name       : " + customer.getFirstName()
                    + " " + customer.getLastName());
            writer.newLine();

            writer.write("Phone      : " + customer.getPhoneNumber());
            writer.newLine();

            writer.write("Email      : " + customer.getEmail());
            writer.newLine();
            // This will change based on if a customer is a member or not
            writer.write("Membership  : " +(customer.isMember()?"Member":"Not a Member"));
            writer.newLine();

            writer.write("----------------------------------------");
            writer.newLine();
        }

        writer.close();
        System.out.println("Customer report saved successfully.");

    } catch (IOException err) {
// If doesn't work
    }
}

// Saves every booking to a text file
// Booking information is stored so it can be restored the next time the application starts
public void saveBookings(ArrayList<Booking> bookings) {
    try {

        BufferedWriter writer = new BufferedWriter(new FileWriter("bookings.txt"));
        for (Booking booking : bookings) {
            // Help aided by ChatGPT to write this part as it was quite repetitive
            writer.write(
                    booking.getBookingId() + ","
                    + booking.getCustomer().getCustomerId() + ","
                    + booking.getRoom().getRoomNumber() + ","
                    + booking.getCheckInDate() + ","
                    + booking.getCheckOutDate() + ","
                    + booking.getCheckInTime() + ","
                    + booking.getCheckOutTime() + ","
                    + booking.getNumberOfGuests() + ","
                    + booking.isExtraBed() + ","
                    + booking.isLateCheckOut() + ","
                    + booking.isAirportShuttle() + ","
                    + booking.getRoomCharge() + ","
                    + booking.getAddOnCharge() + ","
                    + booking.getMembershipFee() + ","
                    + booking.getMemberDiscount() + ","
                    + booking.getTotalPrice()
            );
            writer.newLine();
        }
        writer.close();

    } catch (IOException err) {
        // Empty
    }

}

public void loadBookings(ArrayList<Booking> bookings, HotelService hotelService) {
    try {
        // Help aided by ChatGPT to write this part as it was repetitive
        BufferedReader reader = new BufferedReader(new FileReader("bookings.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            int bookingId = Integer.parseInt(data[0]);
            int customerId = Integer.parseInt(data[1]);
            int roomNumber = Integer.parseInt(data[2]);
            LocalDate checkInDate = LocalDate.parse(data[3]);
            LocalDate checkOutDate = LocalDate.parse(data[4]);
            LocalTime checkInTime = LocalTime.parse(data[5]);
            LocalTime checkOutTime = LocalTime.parse(data[6]);
            int numberOfGuests = Integer.parseInt(data[7]);
            boolean extraBed = Boolean.parseBoolean(data[8]);
            boolean lateCheckOut = Boolean.parseBoolean(data[9]);
            boolean airportShuttle = Boolean.parseBoolean(data[10]);
            double roomCharge = Double.parseDouble(data[11]);
            double addOnCharge = Double.parseDouble(data[12]);
            double membershipFee = Double.parseDouble(data[13]);
            double memberDiscount = Double.parseDouble(data[14]);
            double totalPrice = Double.parseDouble(data[15]);

            Customer customer = hotelService.findCustomerById(customerId);
            Room room = hotelService.findRoomByNumber(roomNumber);

            if (customer != null && room != null) {

                Booking booking = new Booking(
                        bookingId,
                        customer,
                        room,
                        checkInDate,
                        checkOutDate,
                        checkInTime,
                        checkOutTime,
                        numberOfGuests,
                        extraBed,
                        lateCheckOut,
                        airportShuttle,
                        roomCharge,
                        addOnCharge,
                        membershipFee,
                        memberDiscount,
                        totalPrice
                );

                bookings.add(booking);
                room.setAvailable(false);
            }
        }
        reader.close();
    } catch (IOException err) {

    }

}

// Generates a report showing whether each room is currently available or booked
public void saveRoomAvailabilityReport(ArrayList<Room> rooms) {

    try {

        BufferedWriter writer = new BufferedWriter(
                new FileWriter("roomAvailabilityReport.txt"));

        writer.write("..............................................");
        writer.newLine();
        writer.write("      ROOM AVAILABILITY REPORT");
        writer.newLine();
        writer.write("...............................................");
        writer.newLine();
        writer.newLine();

        for (Room room : rooms) {

            writer.write("Room Number: " +room.getRoomNumber());
            writer.newLine();

            writer.write("Room Type: "+room.getClass().getSimpleName());
            writer.newLine();
            // Status changes based on available room or booked room
            writer.write("Status      : "
                    + (room.isAvailable() ?"Available" : "Booked"));
            writer.newLine();

            writer.write("----------------------------------------");
            writer.newLine();
        }
        writer.close();
        System.out.println("Room availability report saved successfully!");

    } catch (IOException err) {
    }
}

// Reads and displays the previously generated room availability report
public void loadRoomAvailabilityReport() {
    try {

        BufferedReader reader = new BufferedReader(
                new FileReader("roomAvailabilityReport.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
        reader.close();

    } catch (IOException err) {
    }

}
}
