
package hotelmanagementsystem.factory;
import hotelmanagementsystem.model.Room;
import hotelmanagementsystem.model.StandardRoom;
import hotelmanagementsystem.model.DeluxeRoom;
import hotelmanagementsystem.model.SuiteRoom;
/**
 *
 * @author pcha2
 */

// Creates Room objects without the rest of the program needing to know which specific room class to create
// This follows the Factory design pattern and supports the Open/Closed principle because new 
// room types can be added here without changing the rest of the system
public class RoomFactory {
    public static Room createRoom(String roomType, int roomNumber, boolean available) {
        switch(roomType) {
            case "StandardRoom":
                return new StandardRoom(roomNumber, available);
            case "DeluxeRoom":
                return new DeluxeRoom(roomNumber, available);
            case "SuiteRoom":
                return new SuiteRoom(roomNumber, available);
            default:
                return null;
        }
    }
}
