package hotelmanagementsystem.service;

import hotelmanagementsystem.model.Booking;
import hotelmanagementsystem.model.Customer;
import hotelmanagementsystem.model.Room;
import hotelmanagementsystem.thread.CustomerSaveThread;
import hotelmanagementsystem.thread.RoomSaveThread;
import hotelmanagementsystem.thread.BookingSaveThread;
import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.LocalTime;
import hotelmanagementsystem.file.FileManager;
import hotelmanagementsystem.interfaces.Chargeable;

// Manages the customers, rooms and bookings in the hotel
public class HotelService {
   
    // This is to store the next customer and booking ID so each is a unique number
    private int nextCustomerId = 1;
    private int nextBookingId = 1;
    private FileManager fileManager;
  
    
    // Stores all customers in the hotel
    private ArrayList<Customer> customers;
    // Stores all rooms in the hotel
    private ArrayList<Room> rooms;
    // Stores all bookings in the hotel
    private ArrayList<Booking> bookings;
    // Allows quick look up of customers using their ID
    private HashMap<Integer, Customer> customerMap;
    // Allows quick lookup of rooms using their room number
    private HashMap<Integer, Room> roomMap;
    
    // Creates the hotelservice and loads any previously saved customers, rooms and bookings into memory
    // fileManager will handle all file input/output
    public HotelService(FileManager fileManager) {
        customers = new ArrayList<>();
        rooms = new ArrayList<>();
        bookings = new ArrayList<>();
        customerMap = new HashMap<>();
        roomMap = new HashMap<>();
        
        // FileManager is supplied by main rather than created inside HotelService
        // This reduces coupling between classes because HotelService does not decide how FileManager is created
        this.fileManager = fileManager;
        

    fileManager.loadCustomers(this);
    fileManager.loadRooms(this);
    fileManager.loadBookings(bookings, this);
    for(Booking booking: bookings) {
        // This will allocate a new booking id
        if (booking.getBookingId()>=nextBookingId) {
            nextBookingId = booking.getBookingId() + 1;
        }
    }
    nextCustomerId = 1;
    for(Customer customer: customers) {
        if (customer.getCustomerId()>= nextCustomerId) {
            // This will allocate customer ID
            nextCustomerId = customer.getCustomerId() + 1;
        }
    }
    }
    // Adds an existing Customer object to the hotel
    // This is used mainly when loading saved customers from a file
    public void addCustomer(Customer customer) {
        customers.add(customer);
        customerMap.put(customer.getCustomerId(), customer);
        CustomerSaveThread thread = new CustomerSaveThread(fileManager, customers);
        thread.start();
    }
    
    // This is if a customer wants to delete a room
    public boolean deleteRoom(int roomNumber) {
    Room room = findRoomByNumber(roomNumber);
    // If the room cannot be found
    if (room == null) {
        return false;
    }

    for (Booking booking : bookings) {
        if (booking.getRoom().getRoomNumber() == roomNumber) {
            return false;
        }

    }

    rooms.remove(room);
    roomMap.remove(roomNumber);
    // Save the updated room list after deletion
    RoomSaveThread thread = new RoomSaveThread(fileManager, rooms);
    thread.start();
// When successfully deleted
    return true;
}
    
    public void generateRoomAvailReport() {
        fileManager.saveRoomAvailabilityReport(rooms);
    }
    public void viewRoomAvailReport() {
        fileManager.loadRoomAvailabilityReport();
    }
    
    
    public void viewCustomerReport() {

    fileManager.loadCustomerReport();

        }
    public void generateCustomerReport() {

    fileManager.saveCustomerReport(customers);

    }   
    public void addRoom(Room room) {
        rooms.add(room);
        roomMap.put(room.getRoomNumber(), room);
        RoomSaveThread thread = new RoomSaveThread(fileManager, rooms);
        thread.start();
    }
    
    // Adds a booking to the hotel
    // The booking parameter is the booking to be added
    public void addBooking(Booking booking) {
        bookings.add(booking);
        BookingSaveThread thread = new BookingSaveThread(fileManager, bookings);
        thread.start();
    }
    
    public Customer findCustomerById(int customerId) {
        return customerMap.get(customerId);
    }
    public Room findRoomByNumber(int roomNumber) {
        return roomMap.get(roomNumber);
    }
    
    public boolean bookRoom(int customerId, int roomNumber, LocalDate checkInDate, LocalTime checkInTime,
  LocalDate checkOutDate, int numberOfGuests, boolean extraBed, boolean lateCheckOut, boolean airportShuttle,
  boolean purchaseMembership) {
        // Find customer using id
        Customer customer = findCustomerById(customerId);
        Room room = findRoomByNumber(roomNumber);
        
        // Does the customer exist?
        if (customer == null) {
            return false;
        }
        
        if (room == null) {
            return false;
        }
        
        if (!room.isAvailable()) {
            return false;
        }
        
        if (numberOfGuests>room.getCapacity()) {
            return false;
        }
        // Days between the check in date and check out date
        long numberOfNights = ChronoUnit.DAYS.between(checkInDate, checkOutDate);
        // They cannot book less than 1 night, not valid
        if (numberOfNights <=0) {
            return false;
        }
        // Using the chargeable interface than depending on the room class for pricing
        // This demonstrates abstraction because HotelService only needs and object capable
        // of calculating a price
        Chargeable chargeable = room;
        double roomCharge = chargeable.calculatePrice((int) numberOfNights);
// These are for optional add ons for the user
double addOnCharge = 0;

if (extraBed) {
    addOnCharge += 40;
}

if (lateCheckOut) {
    addOnCharge += 30;
}

if (airportShuttle) {
    addOnCharge += 60;
}

double membershipFee = 0;

if (purchaseMembership && !customer.isMember()) {
    membershipFee = 75;
    customer.setMember(true); // Customer becomes a member
    
    // Saving the updated membership status
    CustomerSaveThread thread = new CustomerSaveThread(fileManager, customers);
    thread.start();
}

// Members recieve a 10% discount on the room charge
// This also applies immediately if a customer purchases a membership during this booking
double memberDiscount = 0;

if (customer.isMember() || purchaseMembership) {
    memberDiscount = roomCharge * 0.10;
}

double totalPrice = roomCharge
        + addOnCharge
        + membershipFee
        - memberDiscount;
        LocalTime checkOutTime;
        
        // For if the customer wants a late check out
        // Default hotel check out time is 12PM, due to add on the customer can change that to 4PM
        if (lateCheckOut) {
            checkOutTime = LocalTime.of(16, 0); // 4 PM
        } else {
            checkOutTime = LocalTime.of(12, 0); // 12 PM
        }
        Booking booking = new Booking(nextBookingId, customer, room, checkInDate,checkOutDate, checkInTime, checkOutTime,
        numberOfGuests, extraBed, lateCheckOut, airportShuttle, roomCharge, addOnCharge, membershipFee, memberDiscount,
        totalPrice);
        
        addBooking(booking);
        // Once a booking is successfully created the room is marked as unavailable 
        // So cannot be marked again unless cancelled
        room.setAvailable(false);
        System.out.println("BOOKING ID: " + booking.getBookingId());
        // Prepare the next booking ID
        nextBookingId++;
        
        return true;
        
    
    }

    // Finding a booking by its booking ID
    // return matching customer or null
    public Booking findBookingById(int bookingId) {
        for (Booking booking: bookings) {
            if (booking.getBookingId() == bookingId) {
                return booking;
            }
        }
        return null;
    }
    
    // Customer wants to cancel the booking
    public boolean cancelBooking(int bookingId) {
        
        Booking booking = findBookingById(bookingId);
        if (booking == null) {
            return false;
        }
       Room room = booking.getRoom();
       room.setAvailable(true);
       bookings.remove(booking);
       BookingSaveThread bookingThread = new BookingSaveThread(fileManager, bookings);
       bookingThread.start();
       RoomSaveThread roomThread = new RoomSaveThread(fileManager, rooms);
       roomThread.start();
       
       return true;
    }
    
    public ArrayList<Customer> getCustomers() {
        return customers;
    }
    public ArrayList<Room> getRooms() {
        return rooms;
    }
    public ArrayList<Booking> getBookings() {
        return bookings;
    }
    
    public boolean deleteCustomer(int customerId) {
        Customer customer = findCustomerById(customerId);
        if (customer == null) {
            return false;
        }
        for (Booking booking: bookings) {
            if (booking.getCustomer().getCustomerId()== customerId) {
                return false;
            }
        }
        customers.remove(customer);
        customerMap.remove(customerId);
        CustomerSaveThread thread = new CustomerSaveThread(fileManager, customers);
        thread.start();
        return true;
    }
    
    // To add a new customer to the system
    // Mapped from the customer id number to the customer
  public void addCustomer(String firstName, String lastName, String phoneNumber, String email) {
      Customer customer = new Customer(nextCustomerId, firstName, lastName, phoneNumber, email, false);
      customers.add(customer);
      customerMap.put(nextCustomerId, customer);
      CustomerSaveThread thread = new CustomerSaveThread(fileManager, customers);
      thread.start();
      nextCustomerId = nextCustomerId + 1;
  }

    public int getNextCustomerId() {
        return nextCustomerId;
    }
    // Does the room exist?
    public boolean roomExists(int roomNumber) {
        return roomMap.containsKey(roomNumber);
    }
    
  
}