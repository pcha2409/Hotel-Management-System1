# Hotel Management System — Project 1

Java console-based hotel management system developed for a university Program Construction course. Features room, customer and booking management, with object-oriented design including a RoomFactory and Chargeable interface.

## Project structure
- `HotelManagementSystem/src/`: Java source code
- `HotelManagementSystem/nbproject/` and `build.xml`: NetBeans/Ant project configuration
- `P79_24263053_AI Log_Functionality.docx`: AI interaction and functionality documentation

## Running
Open `HotelManagementSystem` as a NetBeans project and build/run it with a suitable JDK. Runtime text data files are intentionally excluded from this public source archive.

This archive contains **Project 1**, not the later Java Swing/Derby Project 2. The original submission demonstration video is omitted to keep the repository lightweight.
